SET SESSION sql_mode='';
SET NAMES 'utf8mb4';

DELETE FROM `PREFIX_smarty_cache`;